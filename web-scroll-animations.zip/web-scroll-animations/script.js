// ============================================
// GSAP ScrollTrigger Initialization
// ============================================

gsap.registerPlugin(ScrollTrigger);

// Mobile detection
const isMobile = window.innerWidth <= 768;

// ============================================
// 1. SMOOTH SCROLL ANIMATIONS WITH GSAP
// ============================================

// Hero title and subtitle animation
gsap.from('.hero-title', {
    duration: 1,
    opacity: 0,
    y: 50,
    delay: 0.3,
    ease: 'power3.out'
});

gsap.from('.hero-subtitle', {
    duration: 1,
    opacity: 0,
    y: 30,
    delay: 0.6,
    ease: 'power3.out'
});

gsap.from('.cta-button:first-of-type', {
    duration: 1,
    opacity: 0,
    scale: 0.9,
    delay: 0.9,
    ease: 'back.out'
});

// ============================================
// 2. FEATURE CARDS SCROLL ANIMATION
// ============================================

const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            markers: false,
            once: true
        },
        duration: 0.8,
        opacity: 0,
        y: 50,
        delay: index * 0.1,
        ease: 'power3.out'
    });

    // Hover effect with GSAP
    card.addEventListener('mouseenter', () => {
        gsap.to(card, {
            duration: 0.3,
            y: -10,
            boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
            ease: 'power2.out'
        });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            duration: 0.3,
            y: 0,
            boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)',
            ease: 'power2.out'
        });
    });
});

// ============================================
// 3. PORTFOLIO ITEMS STAGGERED ANIMATION
// ============================================

const portfolioItems = document.querySelectorAll('.portfolio-item');
gsap.from(portfolioItems, {
    scrollTrigger: {
        trigger: '.portfolio-container',
        start: 'top 70%',
        markers: false,
        once: true
    },
    duration: 0.8,
    opacity: 0,
    y: 60,
    stagger: 0.15,
    ease: 'power3.out'
});

// Portfolio item scale effect on scroll
portfolioItems.forEach((item) => {
    gsap.from(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top center',
            end: 'bottom center',
            scrub: 0.5,
            markers: false
        },
        scale: 0.95,
        opacity: 0.8
    });
});

// ============================================
// 4. STATS COUNTER ANIMATION
// ============================================

const stats = document.querySelectorAll('.stat-number');
let counterStarted = false;

function animateCounters() {
    if (counterStarted) return;
    counterStarted = true;

    stats.forEach((stat) => {
        const target = parseInt(stat.textContent.replace(/\D/g, ''));
        const text = stat.textContent.replace(/\d/g, '');

        gsap.to({ value: 0 }, {
            duration: 2,
            value: target,
            ease: 'power2.out',
            onUpdate: function () {
                stat.textContent = Math.floor(this.targets()[0].value) + text;
            }
        });
    });
}

// Trigger counter animation when stats section is visible
const statsSection = document.querySelector('.stats');
if (statsSection) {
    ScrollTrigger.create({
        trigger: statsSection,
        start: 'top 70%',
        onEnter: animateCounters,
        once: true
    });
}

// ============================================
// 5. TESTIMONIAL CARDS ANIMATION
// ============================================

const testimonialCards = document.querySelectorAll('.testimonial-card');
testimonialCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 75%',
            markers: false,
            once: true
        },
        duration: 0.8,
        opacity: 0,
        x: index % 2 === 0 ? -50 : 50,
        delay: index * 0.1,
        ease: 'power3.out'
    });
});

// ============================================
// 6. PARALLAX EFFECT
// ============================================

gsap.utils.toArray('.portfolio-image').forEach((image) => {
    gsap.to(image, {
        scrollTrigger: {
            trigger: image,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1,
            markers: false
        },
        y: isMobile ? 20 : 50,
        ease: 'none'
    });
});

// ============================================
// 7. CTA SECTION ANIMATION
// ============================================

gsap.from('.cta-section h2', {
    scrollTrigger: {
        trigger: '.cta-section',
        start: 'top 70%',
        markers: false,
        once: true
    },
    duration: 1,
    opacity: 0,
    y: 40,
    ease: 'power3.out'
});

gsap.from('.cta-section p', {
    scrollTrigger: {
        trigger: '.cta-section',
        start: 'top 70%',
        markers: false,
        once: true
    },
    duration: 1,
    opacity: 0,
    y: 40,
    delay: 0.2,
    ease: 'power3.out'
});

gsap.from('.cta-button-large', {
    scrollTrigger: {
        trigger: '.cta-section',
        start: 'top 70%',
        markers: false,
        once: true
    },
    duration: 1,
    opacity: 0,
    scale: 0.8,
    delay: 0.4,
    ease: 'back.out'
});

// ============================================
// 8. INTERSECTION OBSERVER API (CSS-based)
// ============================================

const observerOptions = {
    threshold: 0.15,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Add observer classes to elements
document.querySelectorAll('.feature-card').forEach((el) => {
    if (!el.classList.contains('observe')) {
        el.classList.add('observe');
    }
    observer.observe(el);
});

// ============================================
// 9. MOBILE HAMBURGER MENU
// ============================================

const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-menu a');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Close menu when link is clicked
navLinks.forEach((link) => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.navbar')) {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }
});

// ============================================
// 10. SMOOTH SCROLL SECTIONS
// ============================================

navLinks.forEach((link) => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);

        if (targetSection) {
            gsap.to(window, {
                duration: 0.8,
                scrollTo: {
                    y: targetSection,
                    offsetY: 60
                },
                ease: 'power2.inOut'
            });
        }
    });
});

// ============================================
// 11. BUTTON CLICK ANIMATIONS
// ============================================

const buttons = document.querySelectorAll('.cta-button');
buttons.forEach((button) => {
    button.addEventListener('click', function () {
        gsap.timeline()
            .to(this, {
                duration: 0.1,
                scale: 0.95,
                ease: 'power2.out'
            }, 0)
            .to(this, {
                duration: 0.2,
                scale: 1,
                ease: 'back.out'
            }, 0.1);
    });

    button.addEventListener('mouseenter', () => {
        gsap.to(button, {
            duration: 0.3,
            y: -3,
            boxShadow: '0 15px 40px rgba(0, 0, 0, 0.3)',
            ease: 'power2.out'
        });
    });

    button.addEventListener('mouseleave', () => {
        gsap.to(button, {
            duration: 0.3,
            y: 0,
            boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)',
            ease: 'power2.out'
        });
    });
});

// ============================================
// 12. SCROLL TO TOP BUTTON
// ============================================

// Create scroll to top button
const scrollTopBtn = document.createElement('button');
scrollTopBtn.textContent = '↑';
scrollTopBtn.className = 'scroll-top-btn';
scrollTopBtn.style.cssText = `
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.5rem;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 999;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
`;

document.body.appendChild(scrollTopBtn);

// Show scroll button on scroll
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        scrollTopBtn.style.opacity = '1';
        scrollTopBtn.style.visibility = 'visible';
    } else {
        scrollTopBtn.style.opacity = '0';
        scrollTopBtn.style.visibility = 'hidden';
    }
});

// Scroll to top on button click
scrollTopBtn.addEventListener('click', () => {
    gsap.to(window, {
        duration: 0.8,
        scrollTo: 0,
        ease: 'power2.inOut'
    });
});

scrollTopBtn.addEventListener('mouseenter', () => {
    gsap.to(scrollTopBtn, {
        duration: 0.3,
        scale: 1.1,
        ease: 'power2.out'
    });
});

scrollTopBtn.addEventListener('mouseleave', () => {
    gsap.to(scrollTopBtn, {
        duration: 0.3,
        scale: 1,
        ease: 'power2.out'
    });
});

// ============================================
// 13. REFRESH SCROLL TRIGGER ON RESIZE
// ============================================

window.addEventListener('resize', () => {
    ScrollTrigger.getAll().forEach((trigger) => {
        trigger.refresh();
    });
});

// ============================================
// 14. PAGE LOAD ANIMATION
// ============================================

window.addEventListener('load', () => {
    ScrollTrigger.refresh();
    gsap.to('body', {
        duration: 0.5,
        opacity: 1,
        ease: 'power2.out'
    });
});

// ============================================
// 15. ACCESSIBILITY & PREFERS-REDUCED-MOTION
// ============================================

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (prefersReducedMotion) {
    gsap.globalTimeline.timeScale(0.5);
    document.documentElement.style.scrollBehavior = 'auto';
}

// Listen for changes to prefers-reduced-motion
window.matchMedia('(prefers-reduced-motion: reduce)').addListener((e) => {
    if (e.matches) {
        gsap.globalTimeline.timeScale(0.5);
    } else {
        gsap.globalTimeline.timeScale(1);
    }
});

console.log('✅ Web Enhanced - Scroll animations loaded successfully!');
